/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:54:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for templatefileconfig
-- ----------------------------
DROP TABLE IF EXISTS `templatefileconfig`;
CREATE TABLE `templatefileconfig` (
  `MODEL_ID` bigint(20) NOT NULL,
  `MODEL_NAME` varchar(100) NOT NULL,
  `MODEL_NOTE` varchar(500) NOT NULL,
  `MODEL_CONFIG` text NOT NULL,
  `UPDATE_TIME` datetime NOT NULL,
  `USER_ID` varchar(50) DEFAULT NULL,
  `USER_NAME` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`MODEL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
