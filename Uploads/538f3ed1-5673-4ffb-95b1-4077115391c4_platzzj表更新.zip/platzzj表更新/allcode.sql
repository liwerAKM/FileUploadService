/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:50:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for allcode
-- ----------------------------
DROP TABLE IF EXISTS `allcode`;
CREATE TABLE `allcode` (
  `all_lbmc` varchar(20) NOT NULL,
  `all_code` varchar(20) NOT NULL,
  `code_name` varchar(20) NOT NULL,
  PRIMARY KEY (`all_lbmc`,`all_code`),
  UNIQUE KEY `INdex_ALLcode` (`all_lbmc`,`all_code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of allcode
-- ----------------------------
INSERT INTO `allcode` VALUES ('凭条打印方式', '0', 'USB驱动打印');
INSERT INTO `allcode` VALUES ('凭条打印方式', '1', 'DLL串口打印');
INSERT INTO `allcode` VALUES ('凭条打印机类型', '1', '美松');
INSERT INTO `allcode` VALUES ('凭条模板类型', '0', '业务成功');
INSERT INTO `allcode` VALUES ('凭条模板类型', '1', '业务失败');
INSERT INTO `allcode` VALUES ('前端版本状态', '1', '未发布');
INSERT INTO `allcode` VALUES ('前端版本状态', '2', '已发布');
INSERT INTO `allcode` VALUES ('前端版本状态', '3', '已撤销');
INSERT INTO `allcode` VALUES ('前端版本状态', '4', '已过期');
INSERT INTO `allcode` VALUES ('前端版本类型', '0', '增量包');
INSERT INTO `allcode` VALUES ('前端版本类型', '1', '全量包');
INSERT INTO `allcode` VALUES ('自助机凭条模板拓展属性1(支付方式)', '0', '通用');
INSERT INTO `allcode` VALUES ('自助机凭条模板拓展属性1(支付方式)', '1', '自费');
INSERT INTO `allcode` VALUES ('自助机凭条模板拓展属性1(支付方式)', '2', '医保');
INSERT INTO `allcode` VALUES ('自助机凭条模板类型', '1', '预约挂号');
INSERT INTO `allcode` VALUES ('自助机凭条模板类型', '2', '门诊缴费');
INSERT INTO `allcode` VALUES ('自助机凭条模板类型', '3', '住院预交金');
INSERT INTO `allcode` VALUES ('自助机类型', '1', '大自助机');
INSERT INTO `allcode` VALUES ('自助机类型', '2', '微自助机');
INSERT INTO `allcode` VALUES ('自助机组类型', '1', '自助机组');
INSERT INTO `allcode` VALUES ('自助机组类型', '2', '单自助机');
INSERT INTO `allcode` VALUES ('自助机配置', '1', '支付账户');
INSERT INTO `allcode` VALUES ('自助机配置', '2', '支付方式');
INSERT INTO `allcode` VALUES ('自助机配置', '3', '开放功能');
INSERT INTO `allcode` VALUES ('页面跳转配置类型', '0', '身份证读卡');
INSERT INTO `allcode` VALUES ('页面跳转配置类型', '2', '医保卡读卡');
INSERT INTO `allcode` VALUES ('驱动状态', '1', '发布');
INSERT INTO `allcode` VALUES ('驱动状态', '2', '测试');
