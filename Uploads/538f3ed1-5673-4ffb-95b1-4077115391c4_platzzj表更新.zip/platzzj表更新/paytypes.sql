/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:54:22
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for paytypes
-- ----------------------------
DROP TABLE IF EXISTS `paytypes`;
CREATE TABLE `paytypes` (
  `DEAL_TYPE` varchar(2) NOT NULL,
  `DEAL_TYPE_NAME` varchar(20) NOT NULL,
  `IsUse` char(1) NOT NULL,
  `Add_Time` datetime NOT NULL,
  `PIC` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`DEAL_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of paytypes
-- ----------------------------
INSERT INTO `paytypes` VALUES ('1', '微信', '1', '2021-07-19 09:24:08', 'pay_wechat.png');
INSERT INTO `paytypes` VALUES ('2', '支付宝', '1', '2021-07-19 09:24:10', 'pay_alipay.png');
INSERT INTO `paytypes` VALUES ('3', '银联', '1', '2021-07-20 19:36:58', 'pay_union.png');
INSERT INTO `paytypes` VALUES ('4', 'POS', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('5', '建行', '1', '2021-07-20 19:36:58', 'pay_cbc.png');
INSERT INTO `paytypes` VALUES ('6', '惠山农商行', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('9', '南京医保', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('98', '数字货币', '1', '2021-07-20 19:36:58', 'pay_dcep.png');
INSERT INTO `paytypes` VALUES ('A', '中国银行POS', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('B', '江苏银行聚合支付', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('C', '建行聚合支付', '1', '2021-07-20 19:36:58', 'pay_cbc.png');
INSERT INTO `paytypes` VALUES ('C2', '建行聚合刷卡付', '1', '2021-07-20 19:36:58', 'pay_cbc.png');
INSERT INTO `paytypes` VALUES ('D', '省医保', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('E', '农行聚合', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('F', '宜兴医保', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('G', '互联网医院统一支付', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('H', '华夏银行POS', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('J', '栖霞建行政融支付', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('L', '工行聚合支付', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('M', '南京银行POS', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('N', '常州医保', '1', '2021-07-20 19:36:58', '');
INSERT INTO `paytypes` VALUES ('P', '信用付', '1', '2021-07-20 19:36:58', 'pay_credit.png');
INSERT INTO `paytypes` VALUES ('Q', '建行建融智慧医疗', '1', '2021-07-20 19:36:58', '');
