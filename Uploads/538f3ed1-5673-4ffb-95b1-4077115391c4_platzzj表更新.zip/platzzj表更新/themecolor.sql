/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:55:19
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for themecolor
-- ----------------------------
DROP TABLE IF EXISTS `themecolor`;
CREATE TABLE `themecolor` (
  `ThemeId` bigint(11) NOT NULL,
  `ThemeName` varchar(30) NOT NULL,
  `ThemeColor` text NOT NULL,
  `IS_USE` varchar(1) NOT NULL,
  `ADD_TIME` datetime NOT NULL,
  PRIMARY KEY (`ThemeId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of themecolor
-- ----------------------------
INSERT INTO `themecolor` VALUES ('1638344279543544', '基础绿', '{\r\n	\"NAME\": \"基础绿\",\r\n	\"DARK_COLOR\": \"0,115,54\",\r\n	\"DARK_FORE_COLOR\": \"255,255,255\",\r\n	\"ACCENT_COLOR\": \"245,0,87\",\r\n	\"ACCENT_FORE_COLOR\": \"255,255,255\",\r\n	\"PRIMARY_COLOR\": \"11,163,97\",\r\n	\"PRIMARY_FORE_COLOR\": \"255,255,255\",\r\n	\"LIGHT_COLOR\": \"86,213,143\",\r\n	\"LIGHT_FORE_COLOR\": \"0,0,0\",\r\n	\"IS_USE_COLOR\": 1\r\n}', '1', '2021-12-01 15:36:03');
INSERT INTO `themecolor` VALUES ('1639481906632659', '基础紫', '{\r\n	\"NAME\": \"基础紫\",\r\n	\"PRIMARY_COLOR\": \"106,27,154\",\r\n	\"PRIMARY_FORE_COLOR\": \"255,255,255\",\r\n	\"LIGHT_COLOR\": \"156,77,204\",\r\n	\"LIGHT_FORE_COLOR\": \"0,0,0\",\r\n	\"DARK_COLOR\": \"56,0,107\",\r\n	\"DARK_FORE_COLOR\": \"255,255,255\",\r\n	\"ACCENT_COLOR\": \"230,81,0\",\r\n	\"ACCENT_FORE_COLOR\": \"255,255,255\",\r\n	\"IS_USE_COLOR\": 1\r\n}', '1', '2021-12-14 19:37:34');
INSERT INTO `themecolor` VALUES ('1639481906734646', '基础粉', '{\r\n	\"NAME\": \"基础粉\",\r\n	\"PRIMARY_COLOR\": \"251,114,153\",\r\n	\"PRIMARY_FORE_COLOR\": \"255,255,255\",\r\n	\"LIGHT_COLOR\": \"255,164,202\",\r\n	\"LIGHT_FORE_COLOR\": \"0,0,0\",\r\n	\"DARK_COLOR\": \"196,64,107\",\r\n	\"DARK_FORE_COLOR\": \"255,255,255\",\r\n	\"ACCENT_COLOR\": \"115,201,229\",\r\n	\"ACCENT_FORE_COLOR\": \"255,255,255\",\r\n	\"IS_USE_COLOR\": 1\r\n}', '1', '2021-12-14 19:40:03');
INSERT INTO `themecolor` VALUES ('1639482221632569', '基础蓝', '{\r\n	\"NAME\": \"基础蓝\",\r\n	\"PRIMARY_COLOR\": \"33,150,243\",\r\n	\"PRIMARY_FORE_COLOR\": \"255,255,255\",\r\n	\"LIGHT_COLOR\": \"110,198,255\",\r\n	\"LIGHT_FORE_COLOR\": \"0,0,0\",\r\n	\"DARK_COLOR\": \"0,105,192\",\r\n	\"DARK_FORE_COLOR\": \"255,255,255\",\r\n	\"ACCENT_COLOR\": \"245,0,87\",\r\n	\"ACCENT_FORE_COLOR\": \"255,255,255\",\r\n	\"IS_USE_COLOR\": 1\r\n}', '1', '2021-12-14 19:43:28');
INSERT INTO `themecolor` VALUES ('1664257029365921', '青绿色(栖霞区医院)', '{\r\n		\"NAME\": \"青绿色(栖霞区医院)\",\r\n		\"DARK_COLOR\": \"48,115,125\",\r\n		\"DARK_FORE_COLOR\": \"255,255,255\",\r\n		\"ACCENT_COLOR\": \"245,0,87\",\r\n		\"ACCENT_FORE_COLOR\": \"255,255,255\",\r\n		\"PRIMARY_COLOR\": \"55,175,193\",\r\n		\"PRIMARY_FORE_COLOR\": \"255,255,255\",\r\n		\"LIGHT_COLOR\": \"103,197,211\",\r\n		\"LIGHT_FORE_COLOR\": \"0,0,0\",\r\n		\"IS_USE_COLOR\": 1}', '1', '2022-09-27 13:36:55');
INSERT INTO `themecolor` VALUES ('1664257029365922', '褐色(高淳中医院)', '{\n		\"NAME\": \"褐色(高淳中医院)\",\n		\"DARK_COLOR\": \"121,81,32\",\n		\"DARK_FORE_COLOR\": \"255,255,255\",\n		\"ACCENT_COLOR\": \"245,0,87\",\n		\"ACCENT_FORE_COLOR\": \"255,255,255\",\n		\"PRIMARY_COLOR\": \"146,97,50\",\n		\"PRIMARY_FORE_COLOR\": \"255,255,255\",\n		\"LIGHT_COLOR\": \"154,105,57\",\n		\"LIGHT_FORE_COLOR\": \"0,0,0\",\n		\"IS_USE_COLOR\": 1\n	}', '1', '2022-09-27 14:43:17');
INSERT INTO `themecolor` VALUES ('1664257029385922', '深绿(中大)', '{\r\n		\"NAME\": \"深绿(中大)\",\r\n		\"DARK_COLOR\": \"0,115,54\",\r\n		\"DARK_FORE_COLOR\": \"255,255,255\",\r\n		\"ACCENT_COLOR\": \"245,0,87\",\r\n		\"ACCENT_FORE_COLOR\": \"255,255,255\",\r\n		\"PRIMARY_COLOR\": \"76,125,44\",\r\n		\"PRIMARY_FORE_COLOR\": \"255,255,255\",\r\n		\"LIGHT_COLOR\": \"103,151,71\",\r\n		\"LIGHT_FORE_COLOR\": \"0,0,0\",\r\n		\"IS_USE_COLOR\": 1\r\n	}', '1', '2022-11-03 14:55:02');
INSERT INTO `themecolor` VALUES ('1664257029386922', '深青(苏大附二)', '{\n		\"NAME\": \"深青(苏大附二)\",\n		\"DARK_COLOR\": \"24,105,119\",\n		\"DARK_FORE_COLOR\": \"255,255,255\",\n		\"ACCENT_COLOR\": \"245,0,87\",\n		\"ACCENT_FORE_COLOR\": \"255,255,255\",\n		\"PRIMARY_COLOR\": \"24,135,154\",\n		\"PRIMARY_FORE_COLOR\": \"255,255,255\",\n		\"LIGHT_COLOR\": \"48,149,166\",\n		\"LIGHT_FORE_COLOR\": \"0,0,0\",\n		\"IS_USE_COLOR\": 1\n	}', '1', '2022-11-03 14:55:02');
INSERT INTO `themecolor` VALUES ('1664257029386923', '粉色(妇幼)', '{\n    \"NAME\": \"粉色(高淳妇幼)\",\n    \"DARK_COLOR\": \"237,120,138\",\n    \"DARK_FORE_COLOR\": \"255,255,255\",\n    \"ACCENT_COLOR\": \"245,0,87\",\n    \"ACCENT_FORE_COLOR\": \"255,255,255\",\n    \"PRIMARY_COLOR\": \"247,101,117\",\n    \"PRIMARY_FORE_COLOR\": \"255,255,255\",\n    \"LIGHT_COLOR\": \"245,115,123\",\n    \"LIGHT_FORE_COLOR\": \"0,0,0\",\n    \"IS_USE_COLOR\": 1\n  }', '1', '2022-11-03 14:55:02');
