/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:52:05
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for factory
-- ----------------------------
DROP TABLE IF EXISTS `factory`;
CREATE TABLE `factory` (
  `Factory_id` int(11) NOT NULL,
  `Factory_Name` varchar(30) NOT NULL,
  `Add_Time` datetime NOT NULL,
  `IsUse` char(1) NOT NULL,
  PRIMARY KEY (`Factory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of factory
-- ----------------------------
INSERT INTO `factory` VALUES ('1', '国光', '2021-12-14 16:42:09', '1');
INSERT INTO `factory` VALUES ('2', '长城', '2021-12-14 17:01:02', '1');
INSERT INTO `factory` VALUES ('3', '柯丽尔', '2021-12-14 17:01:02', '1');
INSERT INTO `factory` VALUES ('4', '东软', '2024-11-07 11:24:52', '1');
INSERT INTO `factory` VALUES ('5', '易联众', '2024-11-07 11:24:57', '1');
INSERT INTO `factory` VALUES ('6', '飞利浦', '2024-11-07 11:25:10', '1');
INSERT INTO `factory` VALUES ('7', '西门子', '2024-11-07 11:25:16', '1');
INSERT INTO `factory` VALUES ('8', '迈瑞', '2024-11-07 11:25:23', '1');
INSERT INTO `factory` VALUES ('9', '强生', '2024-11-07 11:25:31', '1');
INSERT INTO `factory` VALUES ('10', '新华医疗', '2024-11-07 11:25:38', '1');
