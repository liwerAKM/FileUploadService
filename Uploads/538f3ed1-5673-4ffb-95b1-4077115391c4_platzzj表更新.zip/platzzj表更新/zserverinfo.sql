/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:56:09
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zserverinfo
-- ----------------------------
DROP TABLE IF EXISTS `zserverinfo`;
CREATE TABLE `zserverinfo` (
  `S_ID` bigint(20) NOT NULL,
  `S_NAME` varchar(50) NOT NULL,
  `S_IP` varchar(20) NOT NULL,
  `S_HTTP_PORT` varchar(20) NOT NULL,
  `S_WS_PORT` varchar(20) NOT NULL,
  `UPDATE_TIME` datetime NOT NULL,
  `UPDATE_USER` varchar(30) NOT NULL,
  `HOS_ID` varchar(20) DEFAULT NULL,
  `IS_USE` int(1) DEFAULT NULL,
  PRIMARY KEY (`S_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
