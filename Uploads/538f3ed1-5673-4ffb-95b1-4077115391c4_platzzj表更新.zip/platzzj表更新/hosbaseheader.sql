/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:52:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for hosbaseheader
-- ----------------------------
DROP TABLE IF EXISTS `hosbaseheader`;
CREATE TABLE `hosbaseheader` (
  `HOS_ID` varchar(10) NOT NULL,
  `HEADER_CONFIG` text NOT NULL,
  `IS_USE` char(1) NOT NULL,
  `ADD_TIME` datetime NOT NULL,
  PRIMARY KEY (`HOS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of hosbaseheader
-- ----------------------------
INSERT INTO `hosbaseheader` VALUES ('1', '{\"HOS_LOGO\":\"logo.png\",\"MAIN_TITLE\":\"江苏启航\",\"SUB_TITLE\":\"\",\"MAIN_QR\":\"wechatMini.png\",\"SUB_QR\":\"\",\"EXTRA_INFO\":\"\"}', '1', '2024-10-22 15:56:35');
