/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:57:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zzjfileinfo
-- ----------------------------
DROP TABLE IF EXISTS `zzjfileinfo`;
CREATE TABLE `zzjfileinfo` (
  `FILE_ID` bigint(20) NOT NULL,
  `FILE_NAME` varchar(200) NOT NULL,
  `FILE_TYPE` varchar(30) NOT NULL,
  `FILE_PATH` varchar(500) NOT NULL,
  `VERSION` varchar(20) NOT NULL,
  `Extension` varchar(20) NOT NULL,
  `NOTE` varchar(100) NOT NULL,
  `UpLoadTime` datetime NOT NULL,
  `CreateTime` datetime NOT NULL,
  `ModifyTime` datetime NOT NULL,
  `FileSize` varchar(50) NOT NULL,
  `HOS_ID` varchar(10) NOT NULL,
  `User_ID` varchar(30) NOT NULL,
  `User_Name` varchar(30) NOT NULL,
  `BUSFUNC_ID` int(11) NOT NULL,
  PRIMARY KEY (`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
