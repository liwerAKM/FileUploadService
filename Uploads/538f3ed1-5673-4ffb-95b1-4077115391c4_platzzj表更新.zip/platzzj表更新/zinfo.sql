/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:55:53
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zinfo
-- ----------------------------
DROP TABLE IF EXISTS `zinfo`;
CREATE TABLE `zinfo` (
  `Z_id` bigint(20) NOT NULL,
  `HOS_ID` varchar(10) NOT NULL,
  `Group_id` bigint(20) NOT NULL,
  `Z_Name` varchar(30) NOT NULL,
  `Z_TYPE` int(11) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Add_Time` datetime NOT NULL,
  `IsUse` char(1) NOT NULL,
  `Status` int(11) NOT NULL DEFAULT '0',
  `ConPaaS` varchar(30) NOT NULL DEFAULT '',
  `IP` varchar(30) NOT NULL,
  `Location` varchar(100) NOT NULL,
  `Model_id` int(11) NOT NULL,
  `ModelBatch_id` bigint(20) NOT NULL,
  `User_ID` varchar(30) NOT NULL,
  `V_ID` bigint(20) DEFAULT NULL,
  `STARTER_VERSION` bigint(20) DEFAULT NULL,
  `LOCAL_V_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Z_id`),
  KEY `RefZGroup30` (`Group_id`),
  KEY `Zinfo_FK1` (`Model_id`),
  KEY `V_ID` (`V_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
