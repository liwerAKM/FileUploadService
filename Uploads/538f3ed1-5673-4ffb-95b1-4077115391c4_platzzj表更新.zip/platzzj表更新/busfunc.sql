/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:51:26
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for busfunc
-- ----------------------------
DROP TABLE IF EXISTS `busfunc`;
CREATE TABLE `busfunc` (
  `BusFunc_id` int(11) NOT NULL,
  `BusFunc_Name` varchar(30) NOT NULL,
  `Add_Time` datetime NOT NULL,
  `IsUse` char(1) NOT NULL,
  `PIC` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`BusFunc_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of busfunc
-- ----------------------------
INSERT INTO `busfunc` VALUES ('1', '当日挂号', '2021-12-20 10:53:28', '1', 'drgh.png');
INSERT INTO `busfunc` VALUES ('2', '预约挂号', '2021-12-14 17:03:45', '1', 'yygh.png');
INSERT INTO `busfunc` VALUES ('3', '门诊缴费', '2021-12-14 17:03:52', '1', 'mzjf.png');
INSERT INTO `busfunc` VALUES ('4', '住院预交金', '2021-12-14 17:04:09', '1', 'zyyjj.png');
INSERT INTO `busfunc` VALUES ('5', '检验报告打印', '2022-02-18 10:08:55', '1', 'jybg.png');
INSERT INTO `busfunc` VALUES ('6', '电子发票打印', '2021-12-14 17:04:22', '1', 'dzfp.png');
INSERT INTO `busfunc` VALUES ('7', '住院清单查询', '2021-12-14 17:04:28', '1', 'zyqd.png');
INSERT INTO `busfunc` VALUES ('8', '出院结算', '2021-12-14 17:04:34', '1', 'cyjs.png');
INSERT INTO `busfunc` VALUES ('9', '入院登记', '2021-12-14 18:15:16', '1', 'rydj.png');
INSERT INTO `busfunc` VALUES ('10', '检查报告打印', '2021-12-14 18:15:05', '1', 'jcbg.png');
INSERT INTO `busfunc` VALUES ('11', '病理报告打印', '2022-05-11 09:47:46', '1', 'blbg.png');
INSERT INTO `busfunc` VALUES ('12', '凭条补打', '2022-05-11 09:47:51', '1', 'ptbd.png');
INSERT INTO `busfunc` VALUES ('13', '预约取号', '2022-06-16 20:43:05', '1', 'yyqh.png');
INSERT INTO `busfunc` VALUES ('14', '预约', '2022-06-16 20:43:46', '1', 'yygh.png');
INSERT INTO `busfunc` VALUES ('15', '个人医保信息查询', '2022-08-15 08:16:14', '1', 'grxxcx.png');
INSERT INTO `busfunc` VALUES ('16', '物价查询', '2022-08-15 08:38:54', '1', 'wjcx.png');
INSERT INTO `busfunc` VALUES ('17', '病历报告打印', '2022-08-15 08:40:45', '1', 'blibg.png');
INSERT INTO `busfunc` VALUES ('18', '体检缴费', '2022-08-15 08:41:44', '1', 'tjjf.png');
INSERT INTO `busfunc` VALUES ('19', '一键核酸', '2022-08-25 17:30:47', '1', 'yjhs.png');
INSERT INTO `busfunc` VALUES ('20', '检验报告补打', '2022-11-01 14:24:54', '1', 'jybgbd.png');
INSERT INTO `busfunc` VALUES ('21', '电子发票补打', '2022-11-01 14:24:59', '1', 'dzfpbd.png');
INSERT INTO `busfunc` VALUES ('22', '病理报告补打', '2022-11-01 14:25:04', '1', 'blbgbd.png');
INSERT INTO `busfunc` VALUES ('23', '病历报告补打', '2022-11-01 14:25:09', '1', 'blibgbd.png');
INSERT INTO `busfunc` VALUES ('24', '核酸报告打印', '2022-11-09 16:41:23', '1', 'hsbg.png');
INSERT INTO `busfunc` VALUES ('25', '健康宣教', '2022-12-05 13:40:35', '1', 'jkxj.png');
INSERT INTO `busfunc` VALUES ('26', '预约取消', '2022-12-05 13:40:35', '1', 'yyqx.png');
INSERT INTO `busfunc` VALUES ('27', '挂号缴费查询（已废弃，使用35）', '2022-12-05 13:40:35', '1', 'ghjfjlcx.png');
INSERT INTO `busfunc` VALUES ('28', '预交金缴纳查询', '2022-12-05 13:40:35', '1', 'yjjjnjlcx.png');
INSERT INTO `busfunc` VALUES ('29', '住院清单打印', '2022-12-05 13:40:35', '1', 'zyqddy.png');
INSERT INTO `busfunc` VALUES ('30', '心电图打印', '2022-12-05 13:40:35', '1', 'xdtdy.png');
INSERT INTO `busfunc` VALUES ('31', '自费转结(门诊)', '2023-02-14 08:24:53', '1', 'zfzj.png');
INSERT INTO `busfunc` VALUES ('32', '满意度评价', '2023-02-14 08:24:53', '1', 'mydpj.png');
INSERT INTO `busfunc` VALUES ('33', '医保政策展示', '2023-02-14 08:24:53', '1', 'ybzczs.png');
INSERT INTO `busfunc` VALUES ('34', '入院前检查缴费', '2023-02-14 08:24:53', '1', 'ryqjcjf.png');
INSERT INTO `busfunc` VALUES ('35', '门诊查询', '2023-02-14 08:24:53', '1', 'mzcx.png');
INSERT INTO `busfunc` VALUES ('36', '治疗信息查询', '2023-02-14 08:24:53', '1', 'zlxxcx.png');
INSERT INTO `busfunc` VALUES ('37', '排队取号', '2023-02-14 08:24:53', '1', 'pdqh.png');
INSERT INTO `busfunc` VALUES ('38', '医院信息查询', '2023-03-09 10:00:35', '1', 'yyxxcx.png');
INSERT INTO `busfunc` VALUES ('39', '检查预约单补打', '2023-03-09 10:00:35', '1', 'jcyydbd.png');
INSERT INTO `busfunc` VALUES ('40', '检查预约改约', '2023-03-09 10:00:35', '1', 'jcyygy.png');
INSERT INTO `busfunc` VALUES ('41', '急诊转诊', '2023-07-17 10:00:35', '1', 'jzzz.png');
INSERT INTO `busfunc` VALUES ('42', '医学证明打印', '2023-09-06 09:10:32', '1', 'yxzmdy.png');
INSERT INTO `busfunc` VALUES ('43', '自助开单', '2023-09-28 10:50:46', '1', 'zzkd.png');
INSERT INTO `busfunc` VALUES ('44', '驾驶员体检缴费', '2023-09-28 10:50:46', '1', 'jsytjjf.png');
INSERT INTO `busfunc` VALUES ('45', '腕带补打', '2024-02-27 08:04:47', '1', 'wdbd.png');
INSERT INTO `busfunc` VALUES ('46', '预约退号', '2024-03-28 08:04:47', '1', 'yyth.png');
INSERT INTO `busfunc` VALUES ('47', '检查预约', '2024-03-28 08:04:47', '1', 'jcyy.png');
INSERT INTO `busfunc` VALUES ('48', '复诊预约', '2024-04-19 08:04:47', '1', 'fzyy.png');
INSERT INTO `busfunc` VALUES ('49', '自费转医保(住院)', '2024-05-22 08:04:47', '1', 'zfzyb.png');
INSERT INTO `busfunc` VALUES ('50', '科室介绍', '2024-08-28 08:04:47', '1', 'ksjs.png');
INSERT INTO `busfunc` VALUES ('51', '医生介绍', '2024-08-28 08:04:47', '1', 'ysjs.png');
INSERT INTO `busfunc` VALUES ('52', '急诊挂号', '2024-08-28 08:04:47', '1', 'jzgh.png');
INSERT INTO `busfunc` VALUES ('53', '就诊签到', '2024-08-28 08:04:47', '1', 'jzqd.png');
