/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:53:46
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for model
-- ----------------------------
DROP TABLE IF EXISTS `model`;
CREATE TABLE `model` (
  `Model_id` int(11) NOT NULL,
  `Model_Name` varchar(30) NOT NULL,
  `Description` varchar(30) NOT NULL,
  `Add_Time` datetime NOT NULL,
  `IsUse` char(1) NOT NULL,
  `Weight` varchar(30) NOT NULL,
  `ScreenSize` varchar(20) NOT NULL,
  `FBL` varchar(30) NOT NULL,
  `Factory_id` int(11) NOT NULL,
  `ExtendProperty` text,
  PRIMARY KEY (`Model_id`),
  KEY `RefFactory1` (`Factory_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of model
-- ----------------------------
INSERT INTO `model` VALUES ('1', '2020A(1080*1920)', '门诊住院报告一体机', '2024-11-07 10:25:54', '1', '1', '', '1080*1920', '1', '[{\"ID\":\"FACTORY_NAME\",\"NAME\":\"国光\"},{\"ID\":\"WINDOW_WIDTH\",\"NAME\":\"1080\"},{\"ID\":\"WINDOW_HEIGHT\",\"NAME\":\"1920\"},{\"ID\":\"TOP_HEIGHT\",\"NAME\":\"0.5*\"},{\"ID\":\"BANNER_HEIGHT\",\"NAME\":\"2*\"},{\"ID\":\"HEADER_HEIGHT\",\"NAME\":\"1*\"},{\"ID\":\"BODY_HEIGHT\",\"NAME\":\"5*\"},{\"ID\":\"FOOT_HEIGHT\",\"NAME\":\"1*\"},{\"ID\":\"BOTTOM_HEIGHT\",\"NAME\":\"0.5*\"}]');
INSERT INTO `model` VALUES ('2', '1010A(1280*960)', '门诊住院报告一体机', '2024-11-07 10:28:47', '1', '1', '', '1280*960', '1', '[{\"ID\":\"FACTORY_NAME\",\"NAME\":\"国光\"},{\"ID\":\"WINDOW_WIDTH\",\"NAME\":\"1280\"},{\"ID\":\"WINDOW_HEIGHT\",\"NAME\":\"960\"},{\"ID\":\"TOP_HEIGHT\",\"NAME\":\"0.5*\"},{\"ID\":\"BANNER_HEIGHT\",\"NAME\":\"0\"},{\"ID\":\"HEADER_HEIGHT\",\"NAME\":\"1.1*\"},{\"ID\":\"BODY_HEIGHT\",\"NAME\":\"6.8*\"},{\"ID\":\"FOOT_HEIGHT\",\"NAME\":\"1.1*\"},{\"ID\":\"BOTTOM_HEIGHT\",\"NAME\":\"0.5*\"}]');
INSERT INTO `model` VALUES ('3', '1551C(1280*1024)', '门诊住院报告一体机', '2024-11-07 10:36:12', '1', '1', '', '1280*1024', '1', '[{\"ID\":\"FACTORY_NAME\",\"NAME\":\"国光\"},{\"ID\":\"WINDOW_WIDTH\",\"NAME\":\"1280\"},{\"ID\":\"WINDOW_HEIGHT\",\"NAME\":\"1024\"},{\"ID\":\"TOP_HEIGHT\",\"NAME\":\"0.5*\"},{\"ID\":\"BANNER_HEIGHT\",\"NAME\":\"0\"},{\"ID\":\"HEADER_HEIGHT\",\"NAME\":\"1.5*\"},{\"ID\":\"BODY_HEIGHT\",\"NAME\":\"6.5*\"},{\"ID\":\"FOOT_HEIGHT\",\"NAME\":\"1*\"},{\"ID\":\"BOTTOM_HEIGHT\",\"NAME\":\"1.5*\"}]');
INSERT INTO `model` VALUES ('4', '1551C定制(1920*1080)', '门诊住院报告一体机', '2024-11-07 10:39:08', '1', '1', '', '1920*1080', '1', '[{\"ID\":\"FACTORY_NAME\",\"NAME\":\"国光\"},{\"ID\":\"WINDOW_WIDTH\",\"NAME\":\"1920\"},{\"ID\":\"WINDOW_HEIGHT\",\"NAME\":\"1080\"},{\"ID\":\"TOP_HEIGHT\",\"NAME\":\"0.5*\"},{\"ID\":\"BANNER_HEIGHT\",\"NAME\":\"0\"},{\"ID\":\"HEADER_HEIGHT\",\"NAME\":\"1.5*\"},{\"ID\":\"BODY_HEIGHT\",\"NAME\":\"6.5*\"},{\"ID\":\"FOOT_HEIGHT\",\"NAME\":\"1*\"},{\"ID\":\"BOTTOM_HEIGHT\",\"NAME\":\"0.5*\"}]');
INSERT INTO `model` VALUES ('5', '1010A(肿瘤定制)', '门诊住院报告一体机', '2024-11-07 10:40:41', '1', '1', '', '1280*960', '1', '[{\"ID\":\"FACTORY_NAME\",\"NAME\":\"国光\"},{\"ID\":\"WINDOW_WIDTH\",\"NAME\":\"1280\"},{\"ID\":\"WINDOW_HEIGHT\",\"NAME\":\"960\"},{\"ID\":\"TOP_HEIGHT\",\"NAME\":\"0.8*\"},{\"ID\":\"BANNER_HEIGHT\",\"NAME\":\"0\"},{\"ID\":\"HEADER_HEIGHT\",\"NAME\":\"1.5*\"},{\"ID\":\"BODY_HEIGHT\",\"NAME\":\"6.5*\"},{\"ID\":\"FOOT_HEIGHT\",\"NAME\":\"0.7*\"},{\"ID\":\"BOTTOM_HEIGHT\",\"NAME\":\"0.5*\"}]');
