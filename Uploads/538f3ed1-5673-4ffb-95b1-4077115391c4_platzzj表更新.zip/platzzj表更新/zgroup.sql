/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:55:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zgroup
-- ----------------------------
DROP TABLE IF EXISTS `zgroup`;
CREATE TABLE `zgroup` (
  `Group_id` bigint(20) NOT NULL,
  `Hos_Id` varchar(10) NOT NULL,
  `Group_Name` varchar(30) NOT NULL,
  `Description` varchar(100) NOT NULL,
  `Add_Time` datetime NOT NULL,
  `IsUse` char(1) NOT NULL,
  `Model` int(11) DEFAULT NULL,
  `ModelBatch_id` bigint(20) DEFAULT NULL,
  `V_ID` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`Group_id`),
  KEY `V_ID` (`V_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `zgroup` (`Group_id`, `Hos_Id`, `Group_Name`, `Description`, `Add_Time`, `IsUse`, `Model`, `ModelBatch_id`, `V_ID`) VALUES ('0', '1', '未分组', '未分组', '2024-10-31 17:08:58', '1', '0', '0', '0');
