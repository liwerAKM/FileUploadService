/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:51:32
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for busidbase
-- ----------------------------
DROP TABLE IF EXISTS `busidbase`;
CREATE TABLE `busidbase` (
  `SYSID_NAME` varchar(20) NOT NULL,
  `MAX_ID` int(11) NOT NULL,
  `Cdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SYSID_NAME`),
  UNIQUE KEY `index_busidbase` (`SYSID_NAME`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of busidbase
-- ----------------------------
