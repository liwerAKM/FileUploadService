/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:56:55
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zzjfileversion
-- ----------------------------
DROP TABLE IF EXISTS `zzjfileversion`;
CREATE TABLE `zzjfileversion` (
  `V_ID` bigint(20) NOT NULL,
  `Version` varchar(30) NOT NULL,
  `V_NAME` varchar(100) NOT NULL,
  `V_NOTE` varchar(200) NOT NULL,
  `USER_ID` varchar(30) NOT NULL,
  `User_Name` varchar(30) NOT NULL,
  `HOS_ID` varchar(10) NOT NULL,
  `CreateTime` datetime NOT NULL,
  `Expire_Time` datetime DEFAULT NULL,
  `PUBLISH_TIME` datetime DEFAULT NULL,
  `DisCardTime` datetime DEFAULT NULL,
  `V_TYPE` int(11) NOT NULL,
  `V_STATUS` int(11) NOT NULL,
  `BusFunc_id` int(11) NOT NULL,
  `PRE_V_ID` bigint(20) NOT NULL,
  PRIMARY KEY (`V_ID`),
  KEY `PRE_V_ID` (`PRE_V_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
