/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:57:10
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zzjversionandfile
-- ----------------------------
DROP TABLE IF EXISTS `zzjversionandfile`;
CREATE TABLE `zzjversionandfile` (
  `V_ID` bigint(20) NOT NULL,
  `FILE_ID` bigint(20) NOT NULL,
  `Direction` varchar(2) NOT NULL,
  PRIMARY KEY (`V_ID`,`FILE_ID`),
  KEY `FILE_ID` (`FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
