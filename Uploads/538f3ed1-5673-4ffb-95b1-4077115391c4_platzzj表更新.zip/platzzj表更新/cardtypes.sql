/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:51:49
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cardtypes
-- ----------------------------
DROP TABLE IF EXISTS `cardtypes`;
CREATE TABLE `cardtypes` (
  `CARD_TYPE` varchar(2) NOT NULL,
  `CARD_NAME` varchar(20) NOT NULL,
  `IsUse` char(1) NOT NULL,
  `Add_Time` datetime NOT NULL,
  `PIC` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`CARD_TYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of cardtypes
-- ----------------------------
INSERT INTO `cardtypes` VALUES ('1', '院内卡', '1', '2021-12-14 17:02:34', 'qrCode.png');
INSERT INTO `cardtypes` VALUES ('11', '电子医保凭证', '1', '2021-12-14 17:02:34', 'eybCard.png');
INSERT INTO `cardtypes` VALUES ('12', '门诊号', '1', '2021-12-14 17:02:34', 'qrCode.png');
INSERT INTO `cardtypes` VALUES ('13', '发票号', '1', '2021-12-14 17:02:34', 'qrCode.png');
INSERT INTO `cardtypes` VALUES ('14', '患者在院唯一号', '1', '2021-12-14 17:02:34', 'qrCode.png');
INSERT INTO `cardtypes` VALUES ('15', '我的南京身份码', '1', '2021-12-14 17:02:34', 'NJIDCode.png');
INSERT INTO `cardtypes` VALUES ('2', '医保卡', '1', '2021-12-14 17:02:34', 'ybCard.png');
INSERT INTO `cardtypes` VALUES ('3', '市民卡', '1', '2021-12-14 17:02:34', 'icCard.png');
INSERT INTO `cardtypes` VALUES ('4', '身份证', '1', '2021-12-14 17:02:34', 'sfz.png');
INSERT INTO `cardtypes` VALUES ('5', '台湾居民来往大陆地区通行证(台胞证)', '1', '2021-12-14 17:02:34', 'TanWanIDCard.png');
INSERT INTO `cardtypes` VALUES ('6', '省医保卡', '1', '2021-12-14 17:02:34', 'sybCard.png');
INSERT INTO `cardtypes` VALUES ('7', '短信验证码', '1', '2021-12-14 17:02:34', 'VeriyCodeCard.png');
INSERT INTO `cardtypes` VALUES ('8', '港澳台通行证', '1', '2021-12-14 17:02:34', 'GATIDCard.png');
INSERT INTO `cardtypes` VALUES ('9', '电子健康卡', '1', '2021-12-14 17:02:34', 'ElecCard.png');
INSERT INTO `cardtypes` VALUES ('91', '手输身份证号', '1', '2022-05-11 09:49:10', 'sfz.png');
INSERT INTO `cardtypes` VALUES ('92', '医保刷脸', '1', '2021-12-14 17:02:34', 'eybCardFace.png');
INSERT INTO `cardtypes` VALUES ('94', '刷脸认证', '1', '2021-12-14 17:02:34', 'faceCode.png');
