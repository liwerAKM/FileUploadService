/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:57:20
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for zzjfiledata
-- ----------------------------
DROP TABLE IF EXISTS `zzjfiledata`;
CREATE TABLE `zzjfiledata` (
  `FILE_ID` bigint(20) NOT NULL,
  `MD5` varchar(40) NOT NULL,
  `FILE_DATA` longblob NOT NULL,
  PRIMARY KEY (`FILE_ID`),
  KEY `MD5` (`MD5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
