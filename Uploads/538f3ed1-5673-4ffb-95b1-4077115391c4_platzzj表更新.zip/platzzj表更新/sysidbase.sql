/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:54:42
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for sysidbase
-- ----------------------------
DROP TABLE IF EXISTS `sysidbase`;
CREATE TABLE `sysidbase` (
  `SYSID_NAME` varchar(30) NOT NULL,
  `MAX_ID` int(11) NOT NULL,
  PRIMARY KEY (`SYSID_NAME`),
  UNIQUE KEY `index_sysidbase` (`SYSID_NAME`) USING HASH
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of sysidbase
-- ----------------------------
INSERT INTO `sysidbase` VALUES ('busfunc', '53');
INSERT INTO `sysidbase` VALUES ('DataVersion', '0');
INSERT INTO `sysidbase` VALUES ('drive', '0');
INSERT INTO `sysidbase` VALUES ('factory', '10');
INSERT INTO `sysidbase` VALUES ('hardware', '0');
INSERT INTO `sysidbase` VALUES ('hosgroupaccountandbusfunc', '0');
INSERT INTO `sysidbase` VALUES ('model', '5');
INSERT INTO `sysidbase` VALUES ('modelbatch', '0');
INSERT INTO `sysidbase` VALUES ('pageinfo', '0');
INSERT INTO `sysidbase` VALUES ('pagejumptype', '0');
INSERT INTO `sysidbase` VALUES ('realhardware', '0');
INSERT INTO `sysidbase` VALUES ('uploadfiletype', '0');
INSERT INTO `sysidbase` VALUES ('zgroup', '0');
