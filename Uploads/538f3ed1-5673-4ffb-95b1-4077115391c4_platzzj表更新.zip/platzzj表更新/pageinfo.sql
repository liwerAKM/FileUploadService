/*
Navicat MySQL Data Transfer

Source Server         : 3.36测试库
Source Server Version : 50731
Source Host           : 192.168.3.36:3307
Source Database       : platzzj_btntoz

Target Server Type    : MYSQL
Target Server Version : 50731
File Encoding         : 65001

Date: 2024-11-07 15:54:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for pageinfo
-- ----------------------------
DROP TABLE IF EXISTS `pageinfo`;
CREATE TABLE `pageinfo` (
  `PAGE_ID` int(11) NOT NULL,
  `PAGE_NAME` varchar(100) NOT NULL,
  `BUSFUNC_ID` int(11) NOT NULL,
  `PAGE_DETAIL` text NOT NULL,
  `IS_USE` char(1) NOT NULL,
  `ADD_TIME` datetime NOT NULL,
  `HOS_ID` varchar(10) NOT NULL,
  PRIMARY KEY (`PAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pageinfo
-- ----------------------------
INSERT INTO `pageinfo` VALUES ('101', '选择卡介质', '0', 'CommFunc.CardList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('102', '操作提示', '0', 'CommFunc.OperTips', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('103', '选择支付', '0', 'CommFunc.ChoosePay', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('104', '支付结算', '0', 'CommFunc.PayQR', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('105', '报告打印', '0', 'CommFunc.ReportPrint', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('106', '凭据打印', '0', 'CommFunc.SlipPrint', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('107', '业务成功', '0', 'CommFunc.Success', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('108', '签到', '0', 'CommFunc.SignIn', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('201', '科室列表', '0', 'Ams.DeptListBase', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('202', '科室排班', '0', 'Ams.SchListBase', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('203', '挂号确认', '0', 'Ams.BookingInfoBase', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('204', '预约列表', '0', 'Ams.BookingList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('205', '退号列表', '0', 'Ams.RefundInfo', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('301', '缴费列表', '0', 'Opt.OptList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('302', '缴费明细', '0', 'Opt.OptDtl', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('303', '缴费确认', '0', 'Opt.OptPayInfo', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('304', '核酸列表', '0', 'Opt.hsType', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('305', '已缴费列表', '0', 'Opt.OptQuery', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('306', '已缴费明细', '0', 'Opt.OptPayDtl', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('307', '门诊支付方式', '0', 'Opt.OptPayTypes', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('308', '检查预约列表', '0', 'Opt.CheckApptList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('309', '检查预约排班', '0', 'Opt.CheckApptSch', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('310', '回执单列表', '0', 'Opt.ReserveList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('311', '自助开单', '0', 'Opt.BillingList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('312', '改约网页', '0', 'Opt.ApptCheckWeb', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('401', '发票列表', '0', 'EInvoice.InvoiceList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('402', '发票评价', '0', 'EInvoice.InvoiceEval', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('501', '操作提示', '0', 'Inpatient.InputHosNum', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('502', '排队取号', '0', 'Inpatient.QueueNumber', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('503', '预交金记录', '0', 'Inpatient.AdPayRecord', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('504', '清单列表', '0', 'Inpatient.CostList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('505', '住院费用信息', '0', 'Inpatient.CostInfo', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('506', '输入预交金', '0', 'Inpatient.InputPayFee', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('507', '入院登记', '0', 'Inpatient.RegBaseInfo', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('508', '腕带信息确认', '0', 'Inpatient.WristbandReprintInfo', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('509', '腕带打印', '0', 'Inpatient.WristbandReprintPrint', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('510', '清单打印', '0', 'Inpatient.ExpenseListPrint', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('511', '住院信息', '0', 'Inpatient.PatInfo', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('512', '出院预结算', '0', 'Inpatient.PreSettlement', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('601', '检验报告', '0', 'ReportPrint.LISRptList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('602', '检查报告', '0', 'ReportPrint.RISRptList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('603', '病理报告', '0', 'ReportPrint.PathoRptList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('604', '病历报告', '0', 'ReportPrint.EMRRptList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('605', '医学证明', '0', 'ReportPrint.MDERptList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('701', '凭条类型', '0', 'SlipReprint.SlipType', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('702', '凭条列表', '0', 'SlipReprint.SlipList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('801', '医保信息', '0', 'Query.PsnInfo', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('802', '物价检索', '0', 'Query.PriceSearch', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('803', '物价列表', '0', 'Query.PriceResult', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('804', '宣教列表', '0', 'Query.HealthEducationList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('805', '宣教内容', '0', 'Query.HealthEducationContent', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('806', '医院简介', '0', 'Query.HosIntro', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('807', '科室简介列表', '0', 'Query.DeptIntroList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('808', '科室简介', '0', 'Query.DeptIntro', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('809', '医生简介列表', '0', 'Query.DocIntroList', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('810', '医生简介', '0', 'Query.DocIntro', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('811', '问卷列表', '0', 'Query.EvalType', '1', '2024-11-07 10:03:35', '1');
INSERT INTO `pageinfo` VALUES ('812', '问卷详情', '0', 'Query.EvalContent', '1', '2024-11-07 10:03:35', '1');
